package com.clipora.ai

import android.os.Bundle
import android.util.Patterns
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.VideoLibrary
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.clipora.ai.data.KeyStore

private val Night = Color(0xFF090B14)
private val Panel = Color(0xFF151A2B)
private val Violet = Color(0xFF8B5CF6)
private val Cyan = Color(0xFF22D3EE)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val keys = KeyStore(this)
        setContent { CliporaApp(keys) }
    }
}

@Composable
private fun CliporaApp(keys: KeyStore) {
    var page by remember { mutableStateOf("home") }
    var url by remember { mutableStateOf("") }
    var status by remember { mutableStateOf("Paste a video link to get started") }
    MaterialTheme(colorScheme = darkColorScheme(background = Night, surface = Panel, primary = Violet)) {
        Scaffold(containerColor = Night) { padding ->
            Column(Modifier.fillMaxSize().padding(padding).verticalScroll(rememberScrollState()).padding(20.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
                    Column {
                        Text("CLIPORA", color = Color.White, fontSize = 25.sp, fontWeight = FontWeight.Black, letterSpacing = 2.sp)
                        Text("AI SHORTS STUDIO", color = Cyan, fontSize = 10.sp, letterSpacing = 2.sp)
                    }
                    IconButton(onClick = { page = if (page == "settings") "home" else "settings" }) {
                        Icon(Icons.Default.Settings, contentDescription = "Settings", tint = Color.White)
                    }
                }
                Spacer(Modifier.height(28.dp))
                if (page == "settings") {
                    SettingsScreen(keys = keys, onBack = { page = "home" })
                } else {
                    Box(Modifier.fillMaxWidth().background(Brush.linearGradient(listOf(Color(0xFF30205F), Color(0xFF123A50))), RoundedCornerShape(24.dp)).padding(22.dp)) {
                        Column {
                            Icon(Icons.Default.AutoAwesome, contentDescription = null, tint = Cyan, modifier = Modifier.size(30.dp))
                            Spacer(Modifier.height(12.dp))
                            Text("Turn long videos into", color = Color.White, fontSize = 24.sp, fontWeight = FontWeight.Bold)
                            Text("scroll-stopping Shorts.", color = Color(0xFFC4B5FD), fontSize = 24.sp, fontWeight = FontWeight.Bold)
                            Spacer(Modifier.height(8.dp))
                            Text("AI-assisted clip ideas, captions and vertical exports — in one place.", color = Color(0xFFE2E8F0), fontSize = 13.sp)
                        }
                    }
                    Spacer(Modifier.height(24.dp))
                    Text("CREATE NEW SHORTS", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 13.sp, letterSpacing = 1.sp)
                    Spacer(Modifier.height(10.dp))
                    OutlinedTextField(value = url, onValueChange = { url = it }, modifier = Modifier.fillMaxWidth(), label = { Text("YouTube video URL") }, placeholder = { Text("https://youtube.com/watch?v=...") }, shape = RoundedCornerShape(16.dp), singleLine = true)
                    Spacer(Modifier.height(12.dp))
                    Button(onClick = {
                        status = when {
                            url.isBlank() -> "Paste a YouTube link first."
                            !Patterns.WEB_URL.matcher(url).matches() -> "That link does not look valid."
                            else -> "Link accepted. Video analysis engine is the next build step."
                        }
                    }, modifier = Modifier.fillMaxWidth().height(54.dp), shape = RoundedCornerShape(16.dp), colors = ButtonDefaults.buttonColors(containerColor = Violet)) {
                        Icon(Icons.Default.AutoAwesome, contentDescription = null)
                        Spacer(Modifier.width(8.dp)); Text("FIND VIRAL MOMENTS", fontWeight = FontWeight.Bold)
                    }
                    Text(status, color = Color(0xFFB8C1D9), fontSize = 12.sp, modifier = Modifier.padding(top = 10.dp))
                    Spacer(Modifier.height(24.dp))
                    FeatureCard("AI MOMENT FINDER", "Find engaging moments from a long video", "Coming in the processing module")
                    FeatureCard("AUTO CAPTIONS", "Generate and style subtitles", "Caption engine integration pending")
                    FeatureCard("9:16 SHORTS EXPORT", "Prepare vertical clips for Shorts and Reels", "FFmpeg pipeline integration pending")
                    Spacer(Modifier.height(18.dp))
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.VideoLibrary, contentDescription = null, tint = Cyan)
                        Spacer(Modifier.width(8.dp))
                        Text("No ads. No ad SDK. No rewarded-ad locks.", color = Cyan, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                    }
                }
            }
        }
    }
}

@Composable
private fun FeatureCard(title: String, description: String, state: String) {
    Card(Modifier.fillMaxWidth().padding(bottom = 10.dp), colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(18.dp)) {
        Column(Modifier.padding(16.dp)) {
            Text(title, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 13.sp)
            Text(description, color = Color(0xFFCBD5E1), fontSize = 12.sp, modifier = Modifier.padding(top = 5.dp))
            Text(state, color = Color(0xFFA78BFA), fontSize = 11.sp, modifier = Modifier.padding(top = 8.dp))
        }
    }
}

@Composable
private fun SettingsScreen(keys: KeyStore, onBack: () -> Unit) {
    var gemini by remember { mutableStateOf(keys.getGeminiKey()) }
    var groq by remember { mutableStateOf(keys.getGroqKey()) }
    var message by remember { mutableStateOf("API keys are stored encrypted on this device.") }
    Text("API SETTINGS", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 18.sp)
    Text("Add your own API keys to enable AI features when their modules are connected.", color = Color(0xFFB8C1D9), fontSize = 12.sp, modifier = Modifier.padding(top = 8.dp, bottom = 18.dp))
    OutlinedTextField(gemini, { gemini = it }, modifier = Modifier.fillMaxWidth(), label = { Text("Gemini API Key") }, singleLine = true)
    Spacer(Modifier.height(12.dp))
    OutlinedTextField(groq, { groq = it }, modifier = Modifier.fillMaxWidth(), label = { Text("Groq API Key") }, singleLine = true)
    Spacer(Modifier.height(16.dp))
    Button(onClick = { keys.saveKeys(gemini, groq); message = "Keys saved securely on this device." }, modifier = Modifier.fillMaxWidth(), colors = ButtonDefaults.buttonColors(containerColor = Violet)) { Text("SAVE API KEYS") }
    Text(message, color = Cyan, fontSize = 12.sp, modifier = Modifier.padding(top = 12.dp))
    TextButton(onClick = onBack) { Text("BACK", color = Color.White) }
}
